#include <stdio.h>
#include <stdlib.h>

/*------------- estructura de datos -------------*/

typedef struct nodoGenerico
{
   int dato;
   struct nodoGenerico* puntero;
}nodo;

typedef struct
{
  int capacidad;
  int size;
  nodo* tope;
}TDApila;

/*------------- operaciones -------------*/

TDApila* crearPilaVacia(int capacidad)
{
  TDApila* pila=(TDApila*)malloc(sizeof(TDApila));
  pila->capacidad=capacidad;
  pila->size=0;
  pila->tope=NULL;
  return pila;
}

int esPilaVacia(TDApila* pila)
{
  if (pila->size == 0)
    return 1;
  else
    return 0;
}


/*------------- Actividad 2 -------------*/
nodo* tope(TDApila* pila);

/*------------- Actividad 3 -------------*/
void apilar(TDApila* pila, int dato);

/*------------- Actividad 4 -------------*/
void desapilar(TDApila* pila);

/*------------- Actividad 5 -------------*/
int buscarDatoPila(TDApila* pila, int dato);




