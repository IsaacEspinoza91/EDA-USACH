#include <stdio.h>
#include <stdlib.h>

/*------------- estructura de datos -------------*/

typedef struct nodoGenerico
{
  int dato;
  struct nodoGenerico* puntero;
}nodo;

typedef nodo* TDAlista;

/*------------- operaciones -------------*/

TDAlista crearListaVacia()
{
  TDAlista lista=(TDAlista)malloc(sizeof(TDAlista));
  lista=NULL;
  return lista;
}

int esListaVacia(TDAlista lista)
{
  if (lista == NULL)
    return 1;
  else
    return 0;
}

void recorrerLista(TDAlista lista)
{
  if (!esListaVacia(lista))
  {
    nodo* auxiliar=lista;
    while (auxiliar!=NULL)
    {
      printf("%d ",auxiliar->dato);
      auxiliar=auxiliar->puntero;
    }
    printf("\n");
  }
  else
    printf("La lista está vacía\n");
}

void insertarInicio(TDAlista* lista, int dato)
{
  nodo* nuevo=(nodo*)malloc(sizeof(nodo));
  nuevo->dato=dato;
  nuevo->puntero=*lista;
  *lista=nuevo;
}

void eliminarInicio(TDAlista* lista)
{
  nodo* auxiliar;
  if(!esListaVacia(*lista))
  {
    auxiliar=*lista;
    *lista=(*lista)->puntero;
    free(auxiliar);
  }
}

/*------------- Actividad 1 -------------*/
int obtenerNumNodos(TDAlista lista){
  if(!esListaVacia(lista)){
    int contador = 0;
    nodo* aux = lista;
    while(aux != NULL){
      contador = contador + 1;
      aux = aux->puntero;
    }
    return contador;

  }else{

    return 0;
  }
}

/*------------- Actividad 2 -------------*/
int buscarDatoLista(TDAlista lista, int dato){
  if(!esListaVacia(lista)){
    nodo* aux = lista;
    while(aux != NULL){
      if(aux->dato == dato){
        printf("El numero %i si esta en la lista\n",dato);
        return 1;
      }
      aux = aux->puntero;
    }
    printf("El numero %i no esta en la lista\n",dato);
    return 0;
  }else{
    printf("El numero %i no esta en la lista\n",dato);
    return 0;
  }
}

/*------------- Actividad 3 -------------*/
void insertarNodoFinal(TDAlista* lista, int dato){
  if(!esListaVacia(*lista)){
    nodo* aux = *lista;
    while(aux != NULL){ //recorremos la lista hasta el final
      aux = aux->puntero;
      if(aux == NULL){  //llegamos al final de lista

        aux->puntero = NULL;

        nodo* nuevoFinal=(nodo*)malloc(sizeof(nodo));
        nuevoFinal->dato=dato;
        nuevoFinal->puntero = NULL;

        aux->puntero = nuevoFinal;

      }
    }
  }
}

void insertarNodoDespues(TDAlista* lista, int dato, int datoAnterior);

/*------------- Actividad 4 -------------*/
void eliminarFinal(TDAlista* lista);
void eliminarDato(TDAlista* lista, int dato);

/*------------- Actividad 5 -------------*/
nodo* obtenerNodo(TDAlista lista, int posicion);