#include <stdio.h>
#include <stdlib.h>
#include "TDAlista.h"

int main()
{
  TDAlista lista=crearListaVacia();

  //Lab 5
  /*ACTIVIDAD 1*/
  //insertar al incio nodos en el siguiente orden: 4,1,3,2
  insertarInicio(&lista, 4);
  insertarInicio(&lista, 1);
  insertarInicio(&lista, 3);
  insertarInicio(&lista, 2);

  //recorremos lista resultante
  //recorrerLista(lista);

  //eliminar nodod al inicio
  eliminarInicio(&lista);

  //recorremos lista resultante
  //recorrerLista(lista);

  //insertar al inicio nodo con valor 2
  insertarInicio(&lista, 2);

  //recorremos lista resultante
  //recorrerLista(lista);

  //obtener cantidad de nodos
  int numNodos = obtenerNumNodos(lista);
  //printf("La lista tiene %i nodos\n",numNodos);

  //verificar si un dato esta en la lista
  buscarDatoLista(lista, 7);
  buscarDatoLista(lista, 1);

  //insertar nodo al final
  insertarNodoFinal(&lista, 99);  






  //Lab 6
  printf("\n\nLAB 6\n");

  //Creamos lista para probar liberarMemoria
  printf("\n\tActividad 1\nliberar lista\n\n");
  TDAlista listax=crearListaVacia();
  insertarInicio(&listax, 99);
  insertarInicio(&listax, 4);
  insertarInicio(&listax, 1);
  liberarLista(&listax);



  //probamos sumar vecinos
  printf("\n\n\n\tActividad 2\n");
  TDAlista listaVeci1=crearListaVacia();
  insertarInicio(&listaVeci1, 2);
  insertarNodoFinal(&listaVeci1, 3);
  insertarNodoFinal(&listaVeci1, 1);
  insertarNodoFinal(&listaVeci1, 4);

  printf("\nlista normal:  ");
  recorrerLista(listaVeci1);
  TDAlista listaVecinosListos = sumaVecinos(listaVeci1);
  printf("lista vecinos sumados:  ");
  recorrerLista(listaVecinosListos);

  eliminarFinal(&listaVeci1);
  eliminarFinal(&listaVeci1);
  printf("\nlista normal:  ");
  recorrerLista(listaVeci1);
  TDAlista listaVecinosListos1 = sumaVecinos(listaVeci1);
  printf("lista vecinos sumados:  ");
  recorrerLista(listaVecinosListos1);

  eliminarFinal(&listaVeci1);
  printf("\nlista normal:  ");
  recorrerLista(listaVeci1);
  TDAlista listaVecinosListos2 = sumaVecinos(listaVeci1);
  printf("lista vecinos sumados:  ");
  recorrerLista(listaVecinosListos2);










  //creamos dos listas para probar funciones
  printf("\n\n\n\tActividad 3");
  TDAlista lista1=crearListaVacia();
  insertarInicio(&lista1, 2);
  insertarNodoFinal(&lista1, 3);
  insertarNodoFinal(&lista1, 1);
  insertarNodoFinal(&lista1, 4);

  TDAlista lista2=crearListaVacia();
  insertarInicio(&lista2, 2);
  insertarNodoFinal(&lista2, 3);
  insertarNodoFinal(&lista2, 1);
  insertarNodoFinal(&lista2, 4);

  //comparar listas EJEMPLO 1
  printf("\n\nLas listas a comparar son :\n");
  recorrerLista(lista1);
  recorrerLista(lista2);
  int k = compararListas(lista1, lista2);
  if(k==1){
    printf("\n   -->  Las listas son iguales\n");
  }else{
    printf("\n   -->  Las listas son distintas\n");
  }


  //comparar listas EJEMPLO 2
  eliminarFinal(&lista2);

  printf("\n\nLas listas a comparar son :\n");
  recorrerLista(lista1);
  recorrerLista(lista2);
  k = compararListas(lista1, lista2);
  if(k==1){
    printf("\n   -->  Las listas son iguales\n");
  }else{
    printf("\n   -->  Las listas son distintas\n");
  }


  //comparar listas EJEMPLO 3
  eliminarInicio(&lista2);
  insertarNodoFinal(&lista2, 4);
  
  printf("\n\nLas listas a comparar son :\n");
  recorrerLista(lista1);
  recorrerLista(lista2);
  k = compararListas(lista1, lista2);
  if(k==1){
    printf("\n   -->  Las listas son iguales\n");
  }else{
    printf("\n   -->  Las listas son distintas\n");
  }





  //lista inversa
  printf("\n\n\n\tActividad 4");
  TDAlista listaInver = listaInversa(lista);   //usamos lista de actividad 1 lab 5
  printf("\nLista original: ");
  recorrerLista(lista);
  printf("La lista invertida es:");
  recorrerLista(listaInver);




  //elementos cambiados
  int posicion1, posicion2;
  printf("\n\n\n\tActividad 5");
  printf("\nLista original: ");
  recorrerLista(lista);
  printf("\nIngrese la primera posicion de los datos que quiere intercambiar (se comienza desde el elemento numero 0): ");
  scanf("%d",&posicion1);
  printf("Ingrese la segunda posicion de los datos que quiere intercambiar (se comienza desde el elemento numero 0): ");
  scanf("%d",&posicion2);
  printf("\nlista con elementos intercambiados: ");
  elementoCambiados(&lista, posicion1, posicion2);
  recorrerLista(lista);





  return 1;
}